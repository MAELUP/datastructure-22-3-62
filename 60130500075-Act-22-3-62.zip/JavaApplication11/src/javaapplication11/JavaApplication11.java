/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Random;

/**
 *
 * @author INT303
 */
public class JavaApplication11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        testPriorityQueue();
    }

    private static void testPriorityQueue() {
        PriorityQueue<Integer> pq = new PriorityQueue(20,new yourComparator());
        Random r = new Random();
        int x;
        for (int i = 0; i < 20; i++) {
            x = r.nextInt(99);
            System.out.print(x + ",");
            pq.offer(x);
        }
        System.out.println("\b\b\n");
        System.out.println("Queue size:" + pq.size());
        System.out.println("Head of queue:" + pq.peek());
        System.out.println(pq);
    }
 
}
class yourComparator implements Comparator<Integer>{

    @Override
    public int compare(Integer o1, Integer o2) {
        return o2-o1;
    }


}
