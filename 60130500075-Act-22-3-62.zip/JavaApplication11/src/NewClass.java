
import java.util.Comparator;
import java.util.PriorityQueue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author INT303
 */
class Student  {

    int id;
    String name;
    double gpax;

    public Student(int id, String name, double gpax) {
        this.id = id;
        this.name = name;
        this.gpax = gpax;

    }

//    @Override
//    public int compare(Student o1, Student o2) {
//   
//                if (o1.gpax < o2.gpax) {
//                    return 1;
//                } else if (o1.gpax > o2.gpax) {
//                    return -1;
//                }
//                return 0;
//            }
    }



public class NewClass {

    public static void main(String[] args) {
        testPriorityQueue();
    }

    private static void testPriorityQueue() {
        PriorityQueue<Student> pq = new PriorityQueue(new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                if (o1.gpax < o2.gpax) {
                    return -1;
                } else if (o1.gpax > o2.gpax) {
                    return 1;
                }
                return 0;
          }
        });
        pq.add(new Student(1001, "A", 2.25));
        pq.add(new Student(1002, "B", 3.25));
        pq.add(new Student(1003, "C", 3.75));
        pq.add(new Student(1004, "D", 1.77));
        pq.add(new Student(1005, "E", 3.58));
        pq.add(new Student(1006, "F", 3.58));
        pq.add(new Student(1007, "G", 2.25));

        for (Student student : pq) {
            System.out.println(student.id + ":" + student.gpax);

        }
        System.out.println("\b\b\n");
        while (!pq.isEmpty()) {
            System.out.println(pq.poll().gpax);

        }
    }

}
